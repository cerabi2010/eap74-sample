importPackage(org.jboss.as.cli.scriptsupport)  
importPackage(javax.management)
importPackage(javax.management.remote)
importPackage(java.util)
 
//날짜포맷 변경을 위한 함수
Date.prototype.format = function() {
   var yyyy = this.getFullYear().toString();
   var mm = (this.getMonth()+1).toString();// getMonth() is zero-based
   var dd  = this.getDate().toString();
   var hh = this.getHours().toString();
    var MM = this.getMinutes().toString();
    var ss = this.getSeconds().toString();
   return yyyy + "-" + (mm[1]?mm:"0"+mm[0]) + "-" + (dd[1]?dd:"0"+dd[0]) + " " + (hh[1]?hh:"0"+hh[0]) + ":" + (MM[1]?MM:"0"+MM[0]) + ":" + (ss[1]?ss:"0"+ss[0]); // padding
};
 
// CLI접속
cli = CLI.newInstance()  

var host = "localhost"
var port = 9990
var pw = new java.lang.String("rplinux12#").toCharArray()

//cli.connect()  
cli.connect (host, port, "admin", pw)
 

 
// Get Listeners
var undertow_result = cli.cmd("/subsystem=undertow/server=default-server:read-resource(recursive=true,include-runtime=true)").getResponse().get("result")
var listeners = ["ajp-listener", "http-listener", "https-listener"]

// workers threads
var io_result = cli.cmd("/subsystem=io:read-resource(recursive=true, include-runtime=true)").getResponse().get("result")
var io_worker = io_result.get("worker")
var io_worker_arr = io_worker.keys().toArray()

// Get Demployment Information for Active Session
var deployment_result = cli.cmd(":read-resource").getResponse().get("result").get("deployment")


// Mbean for IO Worker
var serviceURL = new JMXServiceURL("service:jmx:remote+http://" + host + ":" + port)
var jmxConnector = JMXConnectorFactory.connect(serviceURL, null);

// get JMX connection
var connection = jmxConnector.getMBeanServerConnection();




// Datasource 리스트
result = cli.cmd("/subsystem=datasources:read-resource")
var ds_set = java.util.Set
ds_set = result.getResponse().get("result").get("data-source").keys()
var ds_arr=ds_set.toArray()
 

var system = java.lang.System

var time_end = 60 * 60 * 1  // 1시간
var Thread = java.lang.Thread;
for (var time=1; time < time_end; time++){

    var now = new Date().format()
    java.lang.System.out.printf("%19s\n", now)

    // Thread Pool Executor
    print ("========================================================================")
    print (" Connector / Worker Thread Pool Information")
    print ("========================================================================")


    // Print Title
    java.lang.System.out.printf("%-15s%11s%17s%13s%15s\n", "  " + "Listener","io-worker", "max-connections", "tcp-backlog", "request-count")
    print ("  ----------------------------------------------------------------------")
    for (var i=0; i < listeners.length; i++){
        var listener = listeners[i]
        var listener_result = undertow_result.get(listener)

        if (listener_result.isDefined()){
            var listener_default_result = listener_result.get("default")

            var worker = listener_default_result.get("worker").asString()
            var max_connections = listener_default_result.get("max-connections").asString()
            var tcp_backlog = listener_default_result.get("tcp-backlog").asString()

    
            result = cli.cmd("/subsystem=undertow/server=default-server/" + listener + "=default:read-resource(include-runtime=true)")
            var request_count = result.getResponse().get("result").get("request-count").asString()

            // Print Data
            java.lang.System.out.printf("%-15s%11s%17s%13s%15s\n", "  " + listener, worker, max_connections, tcp_backlog, request_count)
        }
 
    }
    print(" ")

    // Print IO Worker Title
    print ("  ----------------------------------------------------------------------")
    java.lang.System.out.printf("%-10s%20s%15s%19s%17s\n", "  " + "Worker", "CoreWorkerPoolSize", "IoThreadCount", "MaxWorkerPoolSize", "WorkerQueueSize")
    print ("  ----------------------------------------------------------------------")

    for (var cnt = 0; cnt < io_worker_arr.length; cnt++){
        var io_worker_name = io_worker_arr[cnt]
        var objectName=new ObjectName("org.xnio:type=Xnio,provider=\"nio\",worker=\"" + io_worker_name + "\"");
        
        // get JMX Attribute value
        var CoreWorkerPoolSize=connection.getAttribute(objectName, "CoreWorkerPoolSize");
        var IoThreadCount=connection.getAttribute(objectName, "IoThreadCount");
        var MaxWorkerPoolSize=connection.getAttribute(objectName, "MaxWorkerPoolSize");
        var WorkerQueueSize=connection.getAttribute(objectName, "WorkerQueueSize");
 
        // Print Worker Data
        java.lang.System.out.printf("%-10s%20s%15s%19s%17s\n", "  " + io_worker_name, CoreWorkerPoolSize, IoThreadCount, MaxWorkerPoolSize, WorkerQueueSize)
    }

    print(" ")
    print(" ")

    print ("================================================================================")
    print (" Datasources Information")
    print ("================================================================================")

    // Print Title
    java.lang.System.out.printf("%-15s%14s%14s%13s%12s%14s\n", "  " + "Datasource","min-pool-size", "max-pool-size", "ActiveCount", "InUseCount", "MaxUsedCount")
    print ("  ------------------------------------------------------------------------------")

    // Print Datasource
    for (cnt=0; cnt < ds_arr.length; cnt++  ) {
        var datasource_name = ds_arr[cnt]
        // Datasource지정
        DATA_SOURCE="/subsystem=datasources/data-source=" + datasource_name
        
        // min / max 사이즈
        result = cli.cmd(DATA_SOURCE + ":read-resource(include-runtime=true)")
        max_pool_size = result.getResponse().get("result").get("max-pool-size") 
        min_pool_size = result.getResponse().get("result").get("min-pool-size")
        
        // pool 통계
        result = cli.cmd(DATA_SOURCE + "/statistics=pool:read-resource(include-runtime=true)")
        ActiveCount = result.getResponse().get("result").get("ActiveCount")
        InUseCount = result.getResponse().get("result").get("InUseCount")
        MaxUsedCount = result.getResponse().get("result").get("MaxUsedCount")
        
        // 출력
        java.lang.System.out.printf("%-15s%14s%14s%13s%12s%14s\n", "  " + datasource_name, min_pool_size, max_pool_size, ActiveCount, InUseCount, MaxUsedCount)
    }
    //eempty line
    print(" ");
    print(" ");

    print ("============================================================")
    print (" Deployments Information")
    print ("============================================================")

    // Print Title
    java.lang.System.out.printf("%-15s%9s%17s\n", "  " + "Deployment", "enabled", "active-sessions")
    print ("  ----------------------------------------------------------")

    // Print Deployments
    if (deployment_result.isDefined()){
        deployment_arr = deployment_result.keys().toArray()
        for (cnt=0; cnt < deployment_arr.length; cnt++  ) {
            deployment_name = deployment_arr[cnt]
            result = cli.cmd( "/deployment=" + deployment_name + ":read-resource(recursive=true, include-runtime=true)")
            ActiveSession = result.getResponse().get("result").get("subsystem").get("undertow").get("active-sessions")
            Enabled = result.getResponse().get("result").get("enabled")

            // Print Deployment data
            java.lang.System.out.printf("%-15s%9s%17s\n", "  " + deployment_name, Enabled, ActiveSession)

        }

    } else {
           print("No Deployment")
           print(" ")
    }
    
    print(" ")
    print(" ")
    print(" ")

    Thread.sleep(2000)
}
connection.

// CLI 종료
cli.disconnect()

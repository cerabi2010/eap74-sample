java -cp rhino-1.7.7.1.jar:jboss-cli-client.jar org.mozilla.javascript.tools.shell.Main -f monitor-eap70.js
